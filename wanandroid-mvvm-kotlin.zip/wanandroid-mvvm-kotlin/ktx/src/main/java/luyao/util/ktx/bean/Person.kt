package luyao.util.ktx.bean

import java.io.Serializable

/**
 * Created by luyao
 * on 2019/7/8 15:55
 */
data class Person(val name:String,val age:Int) : Serializable