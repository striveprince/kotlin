package luyao.wanandroid.model.bean

/**
 * Created by Lu
 * on 2018/4/2 21:52
 */
data class Hot(val id: Int,
               val link: String,
               val name: String,
               val order: Int,
               val visible: Int,
               val icon: String)